# Grama-Suvidha Portal - Project Requirements

## 1. The Problem Statement
There is often a transparency gap in rural infrastructure. Citizens in a Panchayat are usually unaware of the progress of local works (e.g., building a community hall, pond rejuvenation). This lack of information leads to a lack of community ownership. A platform is needed to visualize "Digital Progress" for village-level assets.

## 2. Detailed Description (The Vision)
Grama-Suvidha is a transparency-focused project tracker. It allows every villager to stay informed about their community. The app lists all government-funded projects in the local area, showing their budget, expected completion date, and current status. It creates a "Digital Notice Board" that ensures every citizen knows exactly where development stands.

## 3. App Usage & User Flow
*   **Project List:** View all ongoing works (e.g., "Main Road Repair," "Borewell Installation").
*   **Progress View:** Tap a project to see a progress bar and status updates (e.g., "50% Complete").
*   **Citizen Feedback:** A simple rating system (1-5 stars) and a "Report Issue" button.
*   **Language:** Full UI support in Kannada to ensure every villager can participate.

## 4. Technical Implementation & Hints
*   **Live Data:** Use LiveData or Flow to update the project progress bar dynamically.
*   **Data Simulation:** Create a mock list of projects in a local JSON file.
*   **Images:** Use Coil or Glide to load mock "Before/After" photos of project sites.

## 5. Impact Goals
*   **Good Governance:** Enhancing transparency and accountability at the grassroots level.
*   **Citizen Engagement:** Moving from passive residents to active "Progress Pilots."
*   **Infrastructure Quality:** Peer-monitoring leads to better construction standards.

## 6. Success Criteria
*   The app must support offline viewing of project lists once data is cached.
*   The progress bar must accurately reflect the percentage stored in the database.
*   The app must allow users to toggle between Kannada and English.
*   Students must document their "Mock API" structure.