---
name: Rural Infrastructure Governance
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424750'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#737781'
  outline-variant: '#c3c6d1'
  surface-tint: '#325f9c'
  primary: '#00366b'
  on-primary: '#ffffff'
  primary-container: '#1b4d89'
  on-primary-container: '#98bfff'
  inverse-primary: '#a7c8ff'
  secondary: '#1c6c40'
  on-secondary: '#ffffff'
  secondary-container: '#a5f4bc'
  on-secondary-container: '#247246'
  tertiary: '#5d2503'
  on-tertiary: '#ffffff'
  tertiary-container: '#7a3b18'
  on-tertiary-container: '#ffa97f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a7c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#114783'
  secondary-fixed: '#a5f4bc'
  secondary-fixed-dim: '#8ad7a2'
  on-secondary-fixed: '#00210f'
  on-secondary-fixed-variant: '#00522c'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb693'
  on-tertiary-fixed: '#341000'
  on-tertiary-fixed-variant: '#733512'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  kannada-body:
    fontFamily: Noto Sans Kannada
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.8'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is built on the pillars of transparency, civic duty, and community growth. It serves as a bridge between administration and the rural populace, necessitating a style that is both institutional and approachable. 

The visual direction follows a **Corporate / Modern** approach with a focus on high legibility and clear information hierarchy. By stripping away unnecessary ornamentation and focusing on structural clarity, the design system ensures that users of all digital literacy levels can navigate infrastructure data with confidence. The aesthetic avoids the coldness of typical tech platforms, instead opting for a grounded, reliable atmosphere that feels like a public utility.

## Colors

The palette is designed to evoke trust and organic progress. 
- **Governance Blue (Primary):** A deep, professional blue used for headers, primary actions, and official markings.
- **Growth Green (Secondary):** A saturated green representing the completion of projects and ecological vitality.
- **Earthy Terracotta (Tertiary):** Used sparingly for accents and secondary information, grounding the digital interface in the physical reality of rural infrastructure.
- **Surface & Neutrals:** Backgrounds utilize a warm "Bone" white to reduce eye strain and provide a softer, more inviting canvas than pure white. 

Functional colors for status badges follow a strict traffic-light logic but are adjusted for high contrast to remain accessible to color-blind users.

## Typography

The typography strategy prioritizes readability above all else. **Public Sans** is selected for its neutral, institutional character and exceptional performance at various scales. 

For the Kannada script, **Noto Sans Kannada** is the mandatory pairing. Because Kannada characters are more intricate than Latin glyphs, the line height for Kannada text should be increased by at least 20% compared to English counterparts to prevent visual crowding. Headlines should remain bold and authoritative, while body text uses a generous 18px base size to ensure accessibility for older citizens.

## Layout & Spacing

This design system utilizes a **Fixed Grid** model for desktop to ensure data density remains manageable and readable on large screens. Content is centered within a 1200px container.

The rhythm is based on an 8px base unit. Wide gutters (24px) are used to create distinct "lanes" of information, reducing cognitive load when viewing complex infrastructure tables or project lists. Vertical spacing should be generous, particularly between unrelated sections, to help users differentiate between project details, financial breakdowns, and feedback areas.

## Elevation & Depth

To maintain a clean and trustworthy feel, this design system avoids heavy shadows or complex gradients. Instead, it utilizes **Tonal Layers** and **Low-contrast outlines**.

- **Cards:** Use a 1px solid border in a soft neutral color (#E0DDD5) rather than a shadow. This creates a clear boundary for project information without cluttering the UI.
- **Active States:** Only primary buttons and active navigation items receive a soft, low-opacity ambient shadow to indicate interactability.
- **Depth:** Content sits on the "Bone" background, while interactive elements (cards, inputs) use a pure white surface to "lift" them toward the user.

## Shapes

The shape language is **Soft**. A subtle corner radius of 0.25rem (4px) is applied to all primary UI elements. This provides a modern, approachable feel while maintaining the "official" look of a government portal. 

Large feedback buttons and status badges may use a slightly higher radius (rounded-lg) to make them feel more tactile and distinct from structural layout containers.

## Components

### Status Badges
Badges use high-contrast text on light-tinted backgrounds for maximum legibility.
- **Ongoing:** Primary Blue text on a light blue background.
- **Completed:** Secondary Green text on a light green background.
- **Delayed:** Warning Red text on a light red background.

### Progress Bars
Progress bars must be thick (minimum 12px height) and utilize the Secondary Green for the fill color. The percentage should always be accompanied by a text label (e.g., "75% Work Finished") to provide context.

### Buttons
Buttons are oversized with a minimum height of 56px to accommodate easy tapping on mobile devices and for users with varying motor skills. The "Give Feedback" button should be a "Floating Action Button" (FAB) style or a prominent full-width button at the bottom of project cards.

### Input Fields
Inputs use high-contrast borders (1.5px) and include clear, persistent labels. Never use placeholder text as a substitute for labels.

### Project Cards
The central component of the design system. Cards must include:
1. Large headline.
2. Prominent status badge in the top-right corner.
3. Summary stats (Budget, Start Date) in a two-column grid.
4. Visual progress bar.